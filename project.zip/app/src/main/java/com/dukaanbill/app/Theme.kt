package com.dukaanbill.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF1B7F5C),
    onPrimary = Color.White,
    secondary = Color(0xFFF2A900),
    background = Color(0xFFF7F9F8),
    surface = Color.White,
    error = Color(0xFFB3261E)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightColors, content = content)
}
