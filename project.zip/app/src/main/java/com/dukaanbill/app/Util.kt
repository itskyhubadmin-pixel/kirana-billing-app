package com.dukaanbill.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

fun Double.money(): String = "₹" + String.format(Locale.US, "%.2f", this)

fun round2(v: Double): Double = Math.round(v * 100.0) / 100.0

fun statusOf(b: Bill): String = when {
    b.paid >= b.total - 0.005 -> "Paid"
    b.paid <= 0.0 -> "Unpaid"
    else -> "Partial"
}

fun formatDate(millis: Long): String =
    SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(millis))

fun startOfDay(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun startOfMonth(): Long = Calendar.getInstance().apply {
    set(Calendar.DAY_OF_MONTH, 1)
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun invoiceText(id: Long, bill: Bill, items: List<BillItem>): String {
    val sb = StringBuilder()
    sb.append("Invoice #").append(id).append('\n')
    sb.append(formatDate(bill.createdAt)).append('\n')
    sb.append("Customer: ").append(bill.customerName).append("\n\n")
    items.forEach {
        sb.append(it.name).append("  ").append(it.qty).append(" x ")
            .append(it.price.money()).append(" = ")
            .append(round2(it.qty * it.price).money()).append('\n')
    }
    sb.append('\n')
    sb.append("Subtotal: ").append(bill.subTotal.money()).append('\n')
    if (bill.discount > 0) sb.append("Discount: -").append(bill.discount.money()).append('\n')
    sb.append("GST: ").append(bill.gst.money()).append('\n')
    sb.append("Total: ").append(bill.total.money()).append('\n')
    sb.append("Paid: ").append(bill.paid.money()).append('\n')
    val due = round2(bill.total - bill.paid)
    if (due > 0) sb.append("Due: ").append(due.money()).append('\n')
    sb.append("\nThank you!")
    return sb.toString()
}

/** Opens WhatsApp click-to-chat if a 10-digit mobile is given, else the normal Android share sheet. */
fun shareText(context: Context, text: String, mobile: String?) {
    try {
        if (!mobile.isNullOrBlank() && mobile.length == 10) {
            val uri = Uri.parse("https://wa.me/91" + mobile + "?text=" + Uri.encode(text))
            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
        } else {
            val send = Intent(Intent.ACTION_SEND)
            send.type = "text/plain"
            send.putExtra(Intent.EXTRA_TEXT, text)
            context.startActivity(Intent.createChooser(send, "Share via"))
        }
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open sharing app", Toast.LENGTH_SHORT).show()
    }
}
