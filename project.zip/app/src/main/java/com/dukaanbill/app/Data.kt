package com.dukaanbill.app

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sellPrice: Double,
    val costPrice: Double,
    val stock: Int,
    val lowStock: Int = 5,
    val gstPercent: Double = 0.0
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val mobile: String
)

@Entity(tableName = "bills")
data class Bill(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long?,
    val customerName: String,
    val createdAt: Long,
    val subTotal: Double,
    val discount: Double,
    val gst: Double,
    val total: Double,
    val paid: Double,
    val cost: Double
)

@Entity(tableName = "bill_items", indices = [Index("billId")])
data class BillItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val billId: Long,
    val productId: Long,
    val name: String,
    val qty: Int,
    val price: Double,
    val cost: Double,
    val gstPercent: Double
)

@Dao
abstract class AppDao {
    @Query("SELECT * FROM products ORDER BY name COLLATE NOCASE")
    abstract fun products(): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun upsertProduct(p: Product): Long

    @Delete
    abstract suspend fun deleteProduct(p: Product)

    @Query("UPDATE products SET stock = stock - :qty WHERE id = :id")
    abstract suspend fun reduceStock(id: Long, qty: Int)

    @Query("SELECT * FROM customers ORDER BY name COLLATE NOCASE")
    abstract fun customers(): Flow<List<Customer>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun upsertCustomer(c: Customer): Long

    @Delete
    abstract suspend fun deleteCustomer(c: Customer)

    @Query("SELECT * FROM bills ORDER BY createdAt DESC")
    abstract fun bills(): Flow<List<Bill>>

    @Insert
    abstract suspend fun insertBill(b: Bill): Long

    @Insert
    abstract suspend fun insertItems(items: List<BillItem>)

    @Query("UPDATE bills SET paid = paid + :amount WHERE id = :id")
    abstract suspend fun addPayment(id: Long, amount: Double)

    @Transaction
    open suspend fun saveBill(b: Bill, items: List<BillItem>): Long {
        val id = insertBill(b)
        insertItems(items.map { it.copy(billId = id) })
        items.forEach { reduceStock(it.productId, it.qty) }
        return id
    }
}

@Database(
    entities = [Product::class, Customer::class, Bill::class, BillItem::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "dukaan.db"
                ).build().also { instance = it }
            }
    }
}
