package com.dukaanbill.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

// ---------- small shared pieces ----------

@Composable
fun AppField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    keyboard: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun RowScope.StatCard(label: String, value: String) {
    Card(modifier = Modifier.weight(1f)) {
        Column(Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun PaymentDialog(due: Double, onDismiss: () -> Unit, onPay: (Double) -> Unit) {
    var text by remember { mutableStateOf(round2(due).toString()) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Receive payment") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Due: " + due.money())
                AppField("Amount received", text, { text = it }, KeyboardType.Decimal)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = text.toDoubleOrNull()
                if (a == null || a <= 0.0 || a > due + 0.005) {
                    error = "Enter an amount between 0 and " + due.money()
                } else {
                    onPay(a)
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ---------- Dashboard ----------

@Composable
fun DashboardScreen(bills: List<Bill>, products: List<Product>, onPay: (Long, Double) -> Unit) {
    var period by remember { mutableIntStateOf(0) }
    val from = when (period) {
        0 -> startOfDay()
        1 -> startOfMonth()
        else -> 0L
    }
    val shown = bills.filter { it.createdAt >= from }
    val revenue = shown.sumOf { it.total }
    val received = shown.sumOf { it.paid }
    val profit = shown.sumOf { it.subTotal - it.discount - it.cost }
    val pending = bills.sumOf { it.total - it.paid }
    val low = products.count { it.stock <= it.lowStock }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Today", "This month", "All time").forEachIndexed { i, label ->
                    if (period == i) {
                        Button(onClick = { period = i }) { Text(label) }
                    } else {
                        OutlinedButton(onClick = { period = i }) { Text(label) }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Orders", shown.size.toString())
                StatCard("Sales (incl. GST)", revenue.money())
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Profit", round2(profit).money())
                StatCard("Received", received.money())
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Pending (all bills)", round2(pending).money())
                StatCard("Low stock items", low.toString())
            }
        }
        item { Text("Bills", style = MaterialTheme.typography.titleMedium) }
        if (shown.isEmpty()) {
            item { Text("No bills in this period.") }
        }
        items(shown.take(100), key = { it.id }) { bill -> BillRow(bill, onPay) }
    }
}

@Composable
fun BillRow(bill: Bill, onPay: (Long, Double) -> Unit) {
    var paying by remember { mutableStateOf(false) }
    val due = round2(bill.total - bill.paid)
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row {
                Text(
                    "Bill #" + bill.id + "  " + bill.customerName,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Text(bill.total.money(), fontWeight = FontWeight.Bold)
            }
            Text(formatDate(bill.createdAt), style = MaterialTheme.typography.bodySmall)
            val status = statusOf(bill)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    status + if (due > 0) "  (due " + due.money() + ")" else "",
                    color = if (status == "Paid") MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.error,
                    modifier = Modifier.weight(1f)
                )
                if (due > 0) {
                    TextButton(onClick = { paying = true }) { Text("Receive payment") }
                }
            }
        }
    }
    if (paying) {
        PaymentDialog(due, { paying = false }) { amount ->
            onPay(bill.id, amount)
            paying = false
        }
    }
}

// ---------- Products ----------

@Composable
fun ProductDialog(initial: Product?, onDismiss: () -> Unit, onSave: (Product) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var sell by remember { mutableStateOf(initial?.sellPrice?.toString() ?: "") }
    var cost by remember { mutableStateOf(initial?.costPrice?.toString() ?: "") }
    var stock by remember { mutableStateOf(initial?.stock?.toString() ?: "") }
    var low by remember { mutableStateOf(initial?.lowStock?.toString() ?: "5") }
    var gst by remember { mutableStateOf(initial?.gstPercent?.toString() ?: "0") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "New product" else "Edit product") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                AppField("Name", name, { name = it })
                AppField("Selling price (Rs, without GST)", sell, { sell = it }, KeyboardType.Decimal)
                AppField("Purchase cost (Rs)", cost, { cost = it }, KeyboardType.Decimal)
                AppField("Stock quantity", stock, { stock = it }, KeyboardType.Number)
                AppField("Low-stock alert at", low, { low = it }, KeyboardType.Number)
                AppField("GST %", gst, { gst = it }, KeyboardType.Decimal)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val s = sell.toDoubleOrNull()
                val c = cost.toDoubleOrNull()
                val st = stock.toIntOrNull()
                val lo = low.toIntOrNull()
                val g = gst.toDoubleOrNull()
                if (name.isBlank()) {
                    error = "Name is required"
                } else if (s == null || s < 0 || c == null || c < 0) {
                    error = "Enter valid prices"
                } else if (st == null || st < 0 || lo == null || lo < 0) {
                    error = "Enter valid stock numbers"
                } else if (g == null || g < 0 || g > 100) {
                    error = "GST must be between 0 and 100"
                } else {
                    onSave(
                        Product(
                            id = initial?.id ?: 0,
                            name = name.trim(),
                            sellPrice = s,
                            costPrice = c,
                            stock = st,
                            lowStock = lo,
                            gstPercent = g
                        )
                    )
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ProductsScreen(
    products: List<Product>,
    onSave: (Product) -> Unit,
    onDelete: (Product) -> Unit
) {
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Product?>(null) }
    var deleting by remember { mutableStateOf<Product?>(null) }

    Box(Modifier.fillMaxSize()) {
        if (products.isEmpty()) {
            Text("No products yet. Tap + to add one.", modifier = Modifier.align(Alignment.Center))
        }
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(products, key = { it.id }) { p ->
                val isLow = p.stock <= p.lowStock
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            Text(
                                "Sell " + p.sellPrice.money() + "  Cost " + p.costPrice.money() +
                                    "  GST " + p.gstPercent + "%",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                "Stock: " + p.stock + if (isLow) "  (LOW)" else "",
                                color = if (isLow) MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        IconButton(onClick = { editing = p }) {
                            Icon(Icons.Filled.Edit, contentDescription = "Edit")
                        }
                        IconButton(onClick = { deleting = p }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete")
                        }
                    }
                }
            }
            item { Box(Modifier.padding(40.dp)) {} }
        }
        FloatingActionButton(
            onClick = { adding = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Filled.Add, contentDescription = "Add product") }
    }

    if (adding) {
        ProductDialog(null, { adding = false }) { onSave(it); adding = false }
    }
    editing?.let { p ->
        ProductDialog(p, { editing = null }) { onSave(it); editing = null }
    }
    deleting?.let { p ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete product?") },
            text = { Text(p.name + " will be removed. Old bills are not affected.") },
            confirmButton = { TextButton(onClick = { onDelete(p); deleting = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

// ---------- Customers ----------

@Composable
fun CustomerDialog(initial: Customer?, onDismiss: () -> Unit, onSave: (Customer) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var mobile by remember { mutableStateOf(initial?.mobile ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "New customer" else "Edit customer") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AppField("Name", name, { name = it })
                AppField("Mobile (10 digits)", mobile, { mobile = it }, KeyboardType.Phone)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val m = mobile.trim()
                if (name.isBlank()) {
                    error = "Name is required"
                } else if (m.isNotEmpty() && (m.length != 10 || !m.all { it.isDigit() })) {
                    error = "Mobile must be exactly 10 digits"
                } else {
                    onSave(Customer(id = initial?.id ?: 0, name = name.trim(), mobile = m))
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun CustomersScreen(
    customers: List<Customer>,
    bills: List<Bill>,
    onSave: (Customer) -> Unit,
    onDelete: (Customer) -> Unit
) {
    val ctx = LocalContext.current
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Customer?>(null) }
    var deleting by remember { mutableStateOf<Customer?>(null) }
    var history by remember { mutableStateOf<Customer?>(null) }

    Box(Modifier.fillMaxSize()) {
        if (customers.isEmpty()) {
            Text("No customers yet. Tap + to add one.", modifier = Modifier.align(Alignment.Center))
        }
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(customers, key = { it.id }) { c ->
                val balance = round2(bills.filter { it.customerId == c.id }.sumOf { it.total - it.paid })
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(c.name, fontWeight = FontWeight.Bold)
                                Text(c.mobile.ifEmpty { "No mobile" }, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    "Balance due: " + balance.money(),
                                    color = if (balance > 0) MaterialTheme.colorScheme.error
                                    else MaterialTheme.colorScheme.onSurface
                                )
                            }
                            IconButton(onClick = { editing = c }) {
                                Icon(Icons.Filled.Edit, contentDescription = "Edit")
                            }
                            IconButton(onClick = { deleting = c }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete")
                            }
                        }
                        Row {
                            TextButton(onClick = { history = c }) { Text("Order history") }
                            if (balance > 0) {
                                TextButton(onClick = {
                                    val msg = "Namaste " + c.name + ", aapka " + balance.money() +
                                        " payment baaki hai. Kripya jaldi payment kar dein. Dhanyavad."
                                    shareText(ctx, msg, c.mobile)
                                }) { Text("Send reminder") }
                            }
                        }
                    }
                }
            }
            item { Box(Modifier.padding(40.dp)) {} }
        }
        FloatingActionButton(
            onClick = { adding = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Filled.Add, contentDescription = "Add customer") }
    }

    if (adding) {
        CustomerDialog(null, { adding = false }) { onSave(it); adding = false }
    }
    editing?.let { c ->
        CustomerDialog(c, { editing = null }) { onSave(it); editing = null }
    }
    deleting?.let { c ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete customer?") },
            text = { Text(c.name + " will be removed. Old bills stay in the records.") },
            confirmButton = { TextButton(onClick = { onDelete(c); deleting = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
    history?.let { c ->
        val list = bills.filter { it.customerId == c.id }
        AlertDialog(
            onDismissRequest = { history = null },
            title = { Text(c.name + " - orders") },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    if (list.isEmpty()) Text("No orders yet.")
                    list.forEach { b ->
                        Text(
                            "#" + b.id + "  " + formatDate(b.createdAt) + "\n" +
                                b.total.money() + "  " + statusOf(b)
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { history = null }) { Text("Close") } }
        )
    }
}

// ---------- Billing ----------

@Composable
fun BillingScreen(
    products: List<Product>,
    customers: List<Customer>,
    onSave: (Bill, List<BillItem>, (Long) -> Unit) -> Unit,
    onMessage: (String) -> Unit
) {
    val ctx = LocalContext.current
    val cart = remember { mutableStateMapOf<Long, Int>() }
    var query by remember { mutableStateOf("") }
    var discountText by remember { mutableStateOf("") }
    var payMode by remember { mutableIntStateOf(0) } // 0 paid, 1 unpaid, 2 partial
    var partialText by remember { mutableStateOf("") }
    var customer by remember { mutableStateOf<Customer?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf<Pair<String, String?>?>(null) }

    fun setQty(id: Long, q: Int) {
        if (q <= 0) cart.remove(id) else cart[id] = q
    }

    val matches = products
        .filter { query.isBlank() || it.name.contains(query, ignoreCase = true) }
        .take(8)
    val lines = products.filter { cart.containsKey(it.id) }
    val subTotal = round2(lines.sumOf { it.sellPrice * (cart[it.id] ?: 0) })
    val discount = round2((discountText.toDoubleOrNull() ?: 0.0).coerceIn(0.0, subTotal))
    val ratio = if (subTotal > 0) (subTotal - discount) / subTotal else 0.0
    val gst = round2(lines.sumOf { it.sellPrice * (cart[it.id] ?: 0) * ratio * it.gstPercent / 100.0 })
    val total = round2(subTotal - discount + gst)
    val partialAmt = partialText.toDoubleOrNull() ?: 0.0
    val paid = when (payMode) {
        0 -> total
        1 -> 0.0
        else -> partialAmt.coerceIn(0.0, total)
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            AppField("Search product", query, { query = it })
        }
        if (products.isEmpty()) {
            item { Text("Add products first (Products tab).") }
        }
        items(matches, key = { "m" + it.id }) { p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(p.name, fontWeight = FontWeight.Bold)
                    Text(p.sellPrice.money() + "  stock " + p.stock, style = MaterialTheme.typography.bodySmall)
                }
                Button(onClick = {
                    val q = cart[p.id] ?: 0
                    if (q + 1 > p.stock) onMessage("Only " + p.stock + " in stock") else setQty(p.id, q + 1)
                }) { Text("Add") }
            }
        }
        if (lines.isNotEmpty()) {
            item { Text("Cart", style = MaterialTheme.typography.titleMedium) }
        }
        items(lines, key = { "c" + it.id }) { p ->
            val q = cart[p.id] ?: 0
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(p.name, modifier = Modifier.weight(1f))
                TextButton(onClick = { setQty(p.id, q - 1) }) { Text("-") }
                Text(q.toString())
                TextButton(onClick = {
                    if (q + 1 > p.stock) onMessage("Only " + p.stock + " in stock") else setQty(p.id, q + 1)
                }) { Text("+") }
                Text(round2(p.sellPrice * q).money(), modifier = Modifier.width(84.dp))
            }
        }
        item {
            Box {
                OutlinedButton(onClick = { menuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                    val c = customer
                    Text(if (c == null) "Walk-in customer" else c.name + " (" + c.mobile + ")")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Walk-in customer") },
                        onClick = { customer = null; menuOpen = false }
                    )
                    customers.forEach { c ->
                        DropdownMenuItem(
                            text = { Text(c.name) },
                            onClick = { customer = c; menuOpen = false }
                        )
                    }
                }
            }
        }
        item { AppField("Discount (Rs)", discountText, { discountText = it }, KeyboardType.Decimal) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                listOf("Paid", "Unpaid", "Partial").forEachIndexed { i, label ->
                    RadioButton(selected = payMode == i, onClick = { payMode = i })
                    Text(label, modifier = Modifier.padding(end = 8.dp))
                }
            }
        }
        if (payMode == 2) {
            item { AppField("Amount received (Rs)", partialText, { partialText = it }, KeyboardType.Decimal) }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Subtotal: " + subTotal.money())
                    Text("Discount: " + discount.money())
                    Text("GST: " + gst.money())
                    Text("Total: " + total.money(), fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium)
                    Text("Paid: " + paid.money() + "   Due: " + round2(total - paid).money())
                }
            }
        }
        item {
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val error: String? = if (lines.isEmpty()) {
                        "Add at least one item"
                    } else if (lines.any { (cart[it.id] ?: 0) > it.stock }) {
                        "Stock is not enough for some items"
                    } else if (payMode != 0 && customer == null) {
                        "Select a customer for unpaid or partial bills"
                    } else if (payMode == 2 && (partialAmt <= 0.0 || partialAmt >= total)) {
                        "Partial amount must be more than 0 and less than the total"
                    } else {
                        null
                    }
                    if (error != null) {
                        onMessage(error)
                    } else {
                        val bill = Bill(
                            customerId = customer?.id,
                            customerName = customer?.name ?: "Walk-in",
                            createdAt = System.currentTimeMillis(),
                            subTotal = subTotal,
                            discount = discount,
                            gst = gst,
                            total = total,
                            paid = paid,
                            cost = round2(lines.sumOf { it.costPrice * (cart[it.id] ?: 0) })
                        )
                        val billItems = lines.map {
                            BillItem(
                                billId = 0,
                                productId = it.id,
                                name = it.name,
                                qty = cart[it.id] ?: 0,
                                price = it.sellPrice,
                                cost = it.costPrice,
                                gstPercent = it.gstPercent
                            )
                        }
                        val mobile = customer?.mobile
                        onSave(bill, billItems) { id ->
                            saved = Pair(invoiceText(id, bill, billItems), mobile)
                            cart.clear()
                            discountText = ""
                            partialText = ""
                            payMode = 0
                            customer = null
                            query = ""
                        }
                    }
                }
            ) { Text("Save bill") }
        }
    }

    saved?.let { pair ->
        AlertDialog(
            onDismissRequest = { saved = null },
            title = { Text("Bill saved") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) { Text(pair.first) }
            },
            confirmButton = {
                TextButton(onClick = { shareText(ctx, pair.first, pair.second) }) { Text("Share") }
            },
            dismissButton = { TextButton(onClick = { saved = null }) { Text("Close") } }
        )
    }
}
