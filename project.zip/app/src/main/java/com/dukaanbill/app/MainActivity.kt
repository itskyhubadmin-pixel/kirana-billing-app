package com.dukaanbill.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                AppRoot()
            }
        }
    }
}

private data class TabItem(val label: String, val icon: ImageVector)

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val products by vm.products.collectAsState()
    val customers by vm.customers.collectAsState()
    val bills by vm.bills.collectAsState()

    val tabs = listOf(
        TabItem("Home", Icons.Filled.Home),
        TabItem("Billing", Icons.Filled.ShoppingCart),
        TabItem("Products", Icons.Filled.Menu),
        TabItem("Customers", Icons.Filled.Person)
    )
    var tab by remember { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val message: (String) -> Unit = { text -> scope.launch { snack.showSnackbar(text) } }

    Scaffold(
        topBar = {
            Surface(color = MaterialTheme.colorScheme.primary) {
                Text(
                    text = "Dukaan Bill  -  " + tabs[tab].label,
                    color = MaterialTheme.colorScheme.onPrimary,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                )
            }
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) }
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { inner ->
        Box(Modifier.padding(inner)) {
            when (tab) {
                0 -> DashboardScreen(bills, products) { id, amt -> vm.addPayment(id, amt) }
                1 -> BillingScreen(
                    products = products,
                    customers = customers,
                    onSave = { bill, items, done -> vm.saveBill(bill, items, done) },
                    onMessage = message
                )
                2 -> ProductsScreen(products, { vm.saveProduct(it) }, { vm.deleteProduct(it) })
                else -> CustomersScreen(
                    customers = customers,
                    bills = bills,
                    onSave = { vm.saveCustomer(it) },
                    onDelete = { vm.deleteCustomer(it) }
                )
            }
        }
    }
}
