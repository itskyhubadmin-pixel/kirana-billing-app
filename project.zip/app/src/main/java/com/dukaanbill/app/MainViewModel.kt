package com.dukaanbill.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()

    private fun <T> Flow<T>.asState(initial: T) =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), initial)

    val products = dao.products().asState(emptyList())
    val customers = dao.customers().asState(emptyList())
    val bills = dao.bills().asState(emptyList())

    fun saveProduct(p: Product) {
        viewModelScope.launch { dao.upsertProduct(p) }
    }

    fun deleteProduct(p: Product) {
        viewModelScope.launch { dao.deleteProduct(p) }
    }

    fun saveCustomer(c: Customer) {
        viewModelScope.launch { dao.upsertCustomer(c) }
    }

    fun deleteCustomer(c: Customer) {
        viewModelScope.launch { dao.deleteCustomer(c) }
    }

    fun saveBill(bill: Bill, items: List<BillItem>, onDone: (Long) -> Unit) {
        viewModelScope.launch {
            val id = dao.saveBill(bill, items)
            onDone(id)
        }
    }

    fun addPayment(billId: Long, amount: Double) {
        viewModelScope.launch { dao.addPayment(billId, amount) }
    }
}
